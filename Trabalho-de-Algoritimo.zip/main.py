from funções import cadastro

nome =input('Digite o nome:')
tipo = int(input('Digite o tipo:'))
preco = float(input('Digite o preço:'))
cadastro( nome,tipo,preco)




