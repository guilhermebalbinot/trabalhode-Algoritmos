class Produto:
  def __init__(slef, nome, codigo, tipo, preço):
    nome = nome
    codigo = codigo
    tipo = tipo 
    preço = preço
    