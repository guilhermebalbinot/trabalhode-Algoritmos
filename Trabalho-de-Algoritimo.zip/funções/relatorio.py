def relatorio():
  peneira = int(input('Digite o númeor da opção que você deseja:  
  \n0 - STodos os produtos \n1 - Somente filmes \n2 - Somente séries \n3 - \n4 -'))