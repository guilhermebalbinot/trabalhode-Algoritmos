import dicionario
def cadastro():
  codigo = int(input('Digite o código do produto:'))
  nome = input('Digite o nome:')
  tipo = int(input('Digite o tipo:'))
  preco = float(input('Digite o preço:'))
  disponivel = bool(input('Está disponível para venda?')
  dicionariO{codigo} = nome,tipo,preco,disponivel

cadastro()