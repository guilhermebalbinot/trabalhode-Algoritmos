import dicionario
def busca():
  codigo = input('Digite o codigo')
  print(dicionario{codigo})